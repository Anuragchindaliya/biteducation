<?php 

//MySQL settings 

//database hostname 
define('DB_HOST', 'localhost'); 


//database name 
define('DB_NAME', 'q2w');


//database username 
define('DB_USER', 'root'); 


//database password 
define('DB_PASSWORD', ''); 


?>