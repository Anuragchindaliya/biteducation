module.exports = {
  reactStrictMode: true,
  images: {
    loader: "akamai",
    path: "./",
  },
  assetPrefix: "./",
};
