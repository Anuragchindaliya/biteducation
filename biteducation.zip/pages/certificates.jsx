import React from 'react'

const certificates = () => {
    return (
        <div>certificates</div>
    )
}

export default certificates